module MainHelper
  def newmethod

  end
end
