class CreateLists < ActiveRecord::Migration
  def change
    create_table :lists do |t|
      t.string :status
      t.string :task
      t.date :due_date

      t.timestamps null: false
    end
  end
end
